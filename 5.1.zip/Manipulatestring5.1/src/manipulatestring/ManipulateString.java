package manipulatestring;

public class ManipulateString {
	public static void main(String[] args) {
		String str="JAVA is Simple";
		System.out.println("a. "+str.toUpperCase());
		System.out.println("b. "+str.toLowerCase());
		
		String[] words=str.split("\\s");
		for(String w:words){  
			System.out.print(w.charAt(0)); 
			System.out.print(" ");
		}
		System.out.println(" ");
		String[] words1=str.split("\\s");
		for(String w:words1){  
			System.out.println(w); 
		}

		StringBuilder words2= new StringBuilder("JAVA is Simple");
		
		System.out.println("String = " + words2.toString());
		StringBuilder reverseStr = words2.reverse();
		System.out.println("Reverse String = " + reverseStr.toString());
	
		System.out.println("length of string " + str.length());
	}

}
